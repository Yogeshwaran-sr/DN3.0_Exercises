package ProxyPatternExample;

public class TestClass {
    public static void main(String[] args) {
        ProxyImage pi = new ProxyImage();
        pi.display("implemented proxy pattern");
    }
}
