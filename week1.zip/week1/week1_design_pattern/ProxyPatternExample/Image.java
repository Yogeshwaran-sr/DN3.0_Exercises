package ProxyPatternExample;

public interface Image {
    void display(String image);
}
