package ObserverPatternExample;

public interface Observer {
    void update(int price);
}
