package AdapterPatternExample;

public class PhonePe {
    public void payment(int amount) {
        System.err.println(amount + "is made via phonepe");
    }
}
