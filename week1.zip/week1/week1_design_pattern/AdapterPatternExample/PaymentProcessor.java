package AdapterPatternExample;

public interface PaymentProcessor {
    void processPayment(int amount);
}
