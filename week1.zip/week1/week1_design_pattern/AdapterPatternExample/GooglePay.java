package AdapterPatternExample;

public class GooglePay {
    public void payment(int amount) {
        System.err.println(amount + "is made via google pay");
    }
}
